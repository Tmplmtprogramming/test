/*********************************************************************
 *                                                                              
 * Copyright 2017  Hanwha Techwin                                              
 *                                                                                                                                                                                                               
 * This software is copyrighted by, and is the sole property
 * of Hanwha Techwin. 
 * 
 * Hanwha Techwin, Co., Ltd. 
 * http://www.hanwhatechwin.co.kr 
*********************************************************************/
/**
 * @file  header.h
 * @brief This file will provide the template for C program coding
 *        standard.
 * @author : taeho07.kim
 * @date : 2017. 3. 24.
 * @version : 
*/

#ifndef HEADER_H_
#define HEADER_H_

#include <string>

using namespace std;

class Header
{
private:
    string className;
    string ObjectID;
public:
    Header()
    {
    }
    virtual ~Header()
    {
    }

    string get_className()
    {
        return this->className;
    }
    string get_objectID()
    {
        return this->ObjectID;
    }

    void read(Tokenizer *pTokenizer, string key)
    {
        className = pTokenizer->read();
    }
};



#endif /* HEADER_H_ */

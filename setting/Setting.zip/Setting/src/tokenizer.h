/*********************************************************************
 *                                                                              
 * Copyright 2017  Hanwha Techwin                                              
 *                                                                                                                                                                                                               
 * This software is copyrighted by, and is the sole property
 * of Hanwha Techwin. 
 * 
 * Hanwha Techwin, Co., Ltd. 
 * http://www.hanwhatechwin.co.kr 
*********************************************************************/
/**
 * @file  tokenizer.h
 * @brief This file will provide the template for C program coding
 *        standard.
 * @author : taeho07.kim
 * @date : 2017. 3. 24.
 * @version : 
*/

#ifndef TOKENIZER_H_
#define TOKENIZER_H_

#include <iostream>
#include <fstream>
#include <string>

#include "parsing_exception.h"

using namespace std;

class Tokenizer
{
private:
    ifstream fin;
public:
    Tokenizer() : fin()
    {
    }
    virtual ~Tokenizer()
    {
        fin.close();
    }

    void open(string fileName)
    {
        fin.open(fileName.c_str());
        if (!fin.is_open())
        {
            throw ParserException(1, fileName);
        }
    }
    string read()
    {
        try
        {
            string token;
            this->fin >> token;
            return token;
        }
	catch (exception& e)
        {
            throw ParserException(2, e.what());
        }
	catch(ParserException& e)
	{
		throw e;
	}
    }
    bool eof()
    {
        return this->fin.eof();
    }
};



#endif /* TOKENIZER_H_ */

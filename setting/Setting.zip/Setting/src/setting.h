/*
 * Setting.h
 *
 *  Created on: 2017. 3. 23.
 *      Author: choi.techwin
 */

#ifndef SETTING_H_
#define SETTING_H_

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <exception>

using namespace std;

class Parser;

class Setting
{
protected:
    virtual void write_body(Parser *pParser) = 0;
    virtual void get_body(Parser *pParser) = 0;

    void write_begin(Parser *pParser, string key);
    void write_end(Parser *pParser);
    void write_int(Parser *pParser, string key, int value);
    void write_float(Parser *pParser, string key, float value);
    void write_string(Parser *pParser, string key, string value);
    int get_begin(Parser *pParser, string key);
    int get_end(Parser *pParser);
    int get_int(Parser *pParser, string key);
    float get_float(Parser *pParser, string key);
    string get_string(Parser *pParser, string key);
    int get_structure(Parser *pParser, string key);

public:
    Setting();
    virtual ~Setting();
    void write(Parser *pParser, string key);
    void get(Parser *pParser, string key);
};

#endif /* SETTING_H_ */

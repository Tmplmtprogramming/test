/*********************************************************************
 *                                                                              
 * Copyright 2017  Hanwha Techwin                                              
 *                                                                                                                                                                                                               
 * This software is copyrighted by, and is the sole property
 * of Hanwha Techwin. 
 * 
 * Hanwha Techwin, Co., Ltd. 
 * http://www.hanwhatechwin.co.kr 
*********************************************************************/
/**
 * @file  video_profile.h
 * @brief This file will provide the template for C program coding
 *        standard.
 * @author : taeho07.kim
 * @date : 2017. 3. 24.
 * @version : 
*/

#ifndef VIDEO_PROFILE_H_
#define VIDEO_PROFILE_H_

#include "setting.h"

class VideoProfile : public Setting
{
private:
    int att3;
    float att4;
protected:
    virtual void write_body(Parser *pParser)
    {
        this->write_int(pParser, "att3", att3);
        this->write_float(pParser, "att4", att4);
    }
    virtual void get_body(Parser *pParser)
    {
        att3 = this->get_int(pParser, "att3");
        att4 = this->get_float(pParser, "att4");
    }
public:
    VideoProfile() : Setting(), att3(0), att4(0)
    {
    }
    virtual ~VideoProfile()
    {
    }
};



#endif /* VIDEO_PROFILE_H_ */

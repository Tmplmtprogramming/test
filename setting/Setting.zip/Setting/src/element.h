/*********************************************************************
 *                                                                              
 * Copyright 2017  Hanwha Techwin                                              
 *                                                                                                                                                                                                               
 * This software is copyrighted by, and is the sole property
 * of Hanwha Techwin. 
 * 
 * Hanwha Techwin, Co., Ltd. 
 * http://www.hanwhatechwin.co.kr 
*********************************************************************/
/**
 * @file  element.h
 * @brief This file will provide the template for C program coding
 *        standard.
 * @author : taeho07.kim
 * @date : 2017. 3. 24.
 * @version : 
*/

#ifndef ELEMENT_H_
#define ELEMENT_H_

#include <string>

#include "tokenizer.h"

using namespace std;

class Element
{
private:
    string key;
    string value;
    void set_value(string value);
protected:
    void set_key(string key);
public:
    Element();
    virtual ~Element();
    virtual bool is_element();
    string get_key();
    string get_value();
    virtual void read(Tokenizer *pTokenizer, string key, string value, string begin, string end);
};



#endif /* ELEMENT_H_ */

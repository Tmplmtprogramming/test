/*********************************************************************
 *                                                                              
 * Copyright 2017  Hanwha Techwin                                              
 *                                                                                                                                                                                                               
 * This software is copyrighted by, and is the sole property
 * of Hanwha Techwin. 
 * 
 * Hanwha Techwin, Co., Ltd. 
 * http://www.hanwhatechwin.co.kr 
 *********************************************************************/
/**
 * @file  parser.h
 * @brief This file will provide the template for C program coding
 *        standard.
 * @author : taeho07.kim
 * @date : 2017. 3. 24.
 * @version : 
 */

#ifndef PARSER_H_
#define PARSER_H_

#include <string>

#include "tokenizer.h"
#include "header.h"
#include "structure.h"

using namespace std;

static string MAIN_KEY = "MAIN";
static string BEGIN = "{";
static string END = "}";
static string DELIMETER = " ";


class Header;
class Structure;
class Element;


class Parser
{
private:
    Tokenizer tokenizer;
    Header header;
    Structure body;
    Element *pCurrent, *pParent;

public:
    Parser();
    virtual ~Parser();
    void read(string kewy);
    Element* get_element(string key);
    int get_int(string key);
    float get_float(string key);
    string get_string(string key);

    template<typename T>
    T get(string key)
    {
        T result;
        Element *pElement = get_element(key);
        stringstream ss;
        ss << pElement->get_value();
        ss >> result;
        return result;
    }
    int get_structure(string key);
    int get_begin(string key);
    int get_end();
    void write_begin(string key);
    void write_end();
    void write_int(string key, int value);
    void write_float(string key, float value);
    void write_string(string key, string value);
    template<typename T>
    void write(string key, T& value)
    {
        stringstream ss;
        ss << value;
        cout << key << DELIMETER << ss.str() << DELIMETER << endl;
    }
};

#endif /* PARSER_H_ */

#include "setting.h"
#include "parser.h"

void Setting::write_begin(Parser* pParser, string key)
{
    pParser->write_begin(key);
}

void Setting::write_end(Parser *pParser)
{
    pParser->write_end();
}
void Setting::write_int(Parser *pParser, string key, int value)
{
    pParser->write_int(key, value);
}
void Setting::write_float(Parser *pParser, string key, float value)
{
    pParser->write_float(key, value);
}
void Setting::write_string(Parser *pParser, string key, string value)
{
    pParser->write_string(key, value);
}

int Setting::get_begin(Parser *pParser, string key)
{
    return pParser->get_begin(key);
}
int Setting::get_end(Parser *pParser)
{
    return pParser->get_end();
}
int Setting::get_int(Parser *pParser, string key)
{
    return pParser->get_int(key);
}
float Setting::get_float(Parser *pParser, string key)
{
    return pParser->get_float(key);
}
string Setting::get_string(Parser *pParser, string key)
{
    return pParser->get_string(key);
}
int Setting::get_structure(Parser *pParser, string key)
{
    return pParser->get_structure(key);
}

Setting::Setting()
{
}
Setting::~Setting()
{
}

void Setting::write(Parser *pParser, string key)
{
    this->write_begin(pParser, key);
    this->write_body(pParser);
    this->write_end(pParser);
}

void Setting::get(Parser *pParser, string key)
{
    this->get_begin(pParser, key);
    this->get_body(pParser);
    this->get_end(pParser);
}

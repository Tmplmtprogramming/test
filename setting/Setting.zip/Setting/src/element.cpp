/*********************************************************************
 *                                                                              
 * Copyright 2017  Hanwha Techwin                                              
 *                                                                                                                                                                                                               
 * This software is copyrighted by, and is the sole property
 * of Hanwha Techwin. 
 * 
 * Hanwha Techwin, Co., Ltd. 
 * http://www.hanwhatechwin.co.kr 
*********************************************************************/
/**
 * @file  element.cpp
 * @brief This file will provide the template for C program coding
 *        standard.
 * @author : taeho07.kim
 * @date : 2017. 3. 25.
 * @version : 
*/
#include "element.h"

void Element::set_value(string value)
{
    this->value = value;
}
void Element::set_key(string key)
{
    this->key = key;
}
Element::Element() { }
Element::~Element() { }

bool Element::is_element() { return true; }
string Element::get_key()
{
    return this->key;
}
string Element::get_value()
{
    return this->value;
}

void Element::read(Tokenizer *pTokenizer, string key, string value, string begin, string end)
{
    this->set_key(key);
    this->set_value(value);
}



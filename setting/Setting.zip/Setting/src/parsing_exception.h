/*********************************************************************
 *                                                                              
 * Copyright 2017  Hanwha Techwin                                              
 *                                                                                                                                                                                                               
 * This software is copyrighted by, and is the sole property
 * of Hanwha Techwin. 
 * 
 * Hanwha Techwin, Co., Ltd. 
 * http://www.hanwhatechwin.co.kr 
*********************************************************************/
/**
 * @file  parsing_exception.h
 * @brief This file will provide the template for C program coding
 *        standard.
 * @author : taeho07.kim
 * @date : 2017. 3. 25.
 * @version : 
*/

#ifndef PARSING_EXCEPTION_H_
#define PARSING_EXCEPTION_H_

#include <string>

using namespace std;

class ParserException
{
protected:
    int id;
    string message;
public:
    ParserException(int id, string message)
    {
        this->id = id;
        this->message = message;
    }
};



#endif /* PARSING_EXCEPTION_H_ */

/*
 * main.cpp
 *
 *  Created on: 2017. 3. 23.
 *      Author: choi.techwin
 */

#include "setting.h"
#include "parser.h"
#include "video_manager.h"

using namespace std;

int main(int argc, char* argv[] ) {
	if(argc == 2)
	{
	    Parser parser;
	    parser.read(argv[1]);

	    VideoManager videoManager;
	    videoManager.get(&parser, "videoManager");
	    videoManager.write(&parser, "videoManager");
	}
	else
	{
		cout << "Please specify the setting file relative path" << endl;
	}
}



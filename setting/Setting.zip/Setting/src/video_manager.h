/*********************************************************************
 *                                                                              
 * Copyright 2017  Hanwha Techwin                                              
 *                                                                                                                                                                                                               
 * This software is copyrighted by, and is the sole property
 * of Hanwha Techwin. 
 * 
 * Hanwha Techwin, Co., Ltd. 
 * http://www.hanwhatechwin.co.kr 
*********************************************************************/
/**
 * @file  video_manager.h
 * @brief This file will provide the template for C program coding
 *        standard.
 * @author : taeho07.kim
 * @date : 2017. 3. 24.
 * @version : 
*/

#ifndef VIDEO_MANAGER_H_
#define VIDEO_MANAGER_H_

#include "setting.h"
#include "video_profile.h"

class VideoManager: public Setting
{
private:
    int att1;
    VideoProfile videoProfile;
    float att2;
protected:
    virtual void write_body(Parser *pParser)
    {
        this->write_int(pParser, "att1", att1);
        videoProfile.write(pParser, "videoProfile");
        this->write_float(pParser, "att2", att2);
    }
    virtual void get_body(Parser *pParser)
    {
        this->att1 = this->get_int(pParser, "att1");
        this->videoProfile.get(pParser, "videoProfile");
        this->att2 = this->get_float(pParser, "att2");
    }

public:
    VideoManager() : att1(0), att2(0)
    {
    }
    virtual ~VideoManager()
    {
    }
};

#endif /* VIDEO_MANAGER_H_ */

/*********************************************************************
 *                                                                              
 * Copyright 2017  Hanwha Techwin                                              
 *                                                                                                                                                                                                               
 * This software is copyrighted by, and is the sole property
 * of Hanwha Techwin. 
 * 
 * Hanwha Techwin, Co., Ltd. 
 * http://www.hanwhatechwin.co.kr 
*********************************************************************/
/**
 * @file  structure.cpp
 * @brief This file will provide the template for C program coding
 *        standard.
 * @author : taeho07.kim
 * @date : 2017. 3. 25.
 * @version : 
*/

#include "structure.h"

Structure::Structure() : Element(), elements() { }
Structure::~Structure() { }

vector<Element *>* Structure::get_elementVector()
{
    return &(this->elements);
}
bool Structure::is_element() { return false; }

void Structure::read(Tokenizer *pTokenizer, string key, string value, string begin, string end)
{
    this->set_key(key);

    Element* pElement = 0;
    string token1 = pTokenizer->read();
    while ((token1 != end) && !pTokenizer->eof())
    {
        string token2 = pTokenizer->read();
        if (token2 == begin)
        {
            pElement = new Structure();
        }
        else
        {
            pElement = new Element();
        }
        pElement->read(pTokenizer, token1, token2, begin, end);
        this->elements.push_back(pElement);
        token1 = pTokenizer->read();
    }
}

Element* Structure::get_element(string key)
{
    for (vector<Element *>::iterator itr = elements.begin(); itr != elements.end(); itr++)
    {
        Element* pElement = *itr;
        if (pElement->get_key() == key)
            return pElement;
    }
    return 0;
}

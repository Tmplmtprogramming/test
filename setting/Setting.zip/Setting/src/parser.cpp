/*********************************************************************
 *                                                                              
 * Copyright 2017  Hanwha Techwin                                              
 *                                                                                                                                                                                                               
 * This software is copyrighted by, and is the sole property
 * of Hanwha Techwin. 
 * 
 * Hanwha Techwin, Co., Ltd. 
 * http://www.hanwhatechwin.co.kr 
 *********************************************************************/
/**
 * @file  parser.cpp
 * @brief This file will provide the template for C program coding
 *        standard.
 * @author : taeho07.kim
 * @date : 2017. 3. 24.
 * @version : 
 */

#include <sstream>

#include "parser.h"
#include "tokenizer.h"
#include "header.h"
#include "structure.h"
#include "element.h"
#include "parsing_exception.h"

Parser::Parser() :
        pCurrent(0), pParent(0)
{
}
Parser::~Parser()
{
}
void Parser::read(string key)
{
//        string fileName = "rsc/" + key + ".txt";
    string fileName = key;
    try
    {
        tokenizer.open(fileName);
        header.read(&tokenizer, key);
        body.read(&tokenizer, key, BEGIN, BEGIN, END);

        this->pCurrent = &this->body;
    } catch (ParserException &e)
    {

    }
}

Element *Parser::get_element(string key)
{
    if (pCurrent->is_element())
    {
        if (pCurrent->get_key() == key)
        {
            return pCurrent;
        }
        return 0;
    }
    vector<Element*> *pElements = ((Structure*) pCurrent)->get_elementVector();
    for (vector<Element *>::iterator itr = pElements->begin(); itr != pElements->end(); itr++)
    {
        if ((*itr)->get_key() == key)
        {
            return (*itr);
        }
    }
    return 0;
}
int Parser::get_structure(string key)
{
    this->pParent = this->pCurrent;
    this->pCurrent = get_element(key);
    return 0;
}
int Parser::get_begin(string key)
{
    this->get_structure(key);
    return 0;
}
int Parser::get_end()
{
    this->pCurrent = this->pParent;
    return 0;
}

void Parser::write_begin(string key)
{
    cout << key;
    cout << endl << BEGIN << endl;
}
void Parser::write_end()
{
    cout << END << DELIMETER <<endl;
}
void Parser::write_int(string key, int value)
{
    this->write(key, value);
}
void Parser::write_float(string key, float value)
{
    this->write(key, value);
}
void Parser::write_string(string key, string value)
{
    this->write(key, value);
}

int Parser::get_int(string key)
{
        return this->get<int>(key);
}

float Parser::get_float(string key)
{
        return this->get<float>(key);
}

string Parser::get_string(string key)
{
        return this->get<string>(key);
}
